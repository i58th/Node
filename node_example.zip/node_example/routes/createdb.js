exports.create=function(req,res){
  nano.db.create(req.body.dbms,function(){
    if(err)
    {
    res.send("Error creating the Database");
    return;
    }
    res.send("Database created successfully");
  });
};